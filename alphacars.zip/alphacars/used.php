<!DOCTYPE html>
<head>
<?php
error_reporting(0);
session_start();
if($_SESSION['loged'])
{
	echo "<script>
	function post()
	{ 
		return true;
	}
	</script>";
}
else
{
 echo "<script>
	function post()
	{ 
	    alert('login first'); 
		window.location='used.php';
   }
	</script>";
}
?>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>carz</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="Alpha Cars is the user frindly website in which people will know all the information about cars." />
	<meta name="keywords" content="Alpha Cars" />
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />
     <script src="send.js"></script>
     <link rel="shortcut icon" href="favicon.ico">

	<link href="https://fonts.googleapis.com/css?family=Raleway:200,300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
<style>
	.sub{
	    background-color:black;
	    color:white;
	}
	.sub:hover{
	    background-color:white;
	    color:black;
	    cursor:pointer;
	}
</style>

</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	
	
	<div id="fh5co-page">
	<header id="fh5co-header" role="banner">
		<div class="container">
			<div class="header-inner" style="position:fixed;left:0px; z-index:10000000; background-color:black; color:white;">
				<h1><a href="#myPage" style="color:white;">Alpha-Cars</a>
				
				<?php
error_reporting(0);

session_start();
if($_SESSION['loged'])
{
echo "<span style='color:white;font-size:18px;position:relative;left:25px'>";
echo $_SESSION['name'];
echo "</span>";
}

?>
				</h1>
				<nav role="navigation">
					<ul style="color:white;">
						<li><a href="index.php" style="color:white;">Home</a></li>
						<li>
					 <a data-toggle="modal" data-target="#myModal" style="cursor:pointer; color:white;">Select</a>
					 </li>
               <li>
					 <a data-toggle="modal" data-target="#compare" style="cursor:pointer;color:white;">Compare</a>
					 </li>
                
				<li><?php
error_reporting(0);

session_start();
if($_SESSION['loged'])
{
echo "<a href='logout.php' style='cursor:pointer;color:white'>Logout</a>";
}
else
{
 echo "<a data-toggle='modal' data-target='#mylog' style='cursor:pointer;color:white'>Login</a>";	
}
?>
				
					</li>
					
					<li>
                        <a data-toggle="modal" data-target="#post" style="cursor:pointer;color:white;"  Onclick="return post()" style="color:white">Post</a>
                    </li>
				<li><a data-toggle="modal" data-target="#reg" style="cursor:pointer;color:white;">Register</a></li>
				<li><a href="used.php" style="color:white;">Used</a></li>
				

					</ul>
				</nav>
			</div>
		</div>
	</header>
	</div>
<div>	
<?php

error_reporting(0);
mysql_connect("localhost","root","") or die("conn error");
mysql_select_db("startupv") or die("db error");

$query=mysql_query("SELECT * FROM usedcars") or die("qu error");
$fields=mysql_num_fields($query);
echo "<div class='row' style='position:relative;top:150px;'>";
while($fetch=mysql_fetch_array($query))	
{   
     
	echo "<div class='col-md-6 animate-box'  style=''>";	
	echo "<div class='row'>";
{
	for($i=1;$i<$fields;$i++)
	{
		
		if($i==1)
	{ 
     echo "<div class='col-sm-4 animate-box'  style=''>";
	echo " <img id='im$fetch[0]' src='pics/".$fetch[$i]."' alt='Image' width='100%' height='200px' onclick='change(this.id)'><br>";
	for($e=$i;$e<=($i+4);$e++)
	{
	echo "<img id='im$fetch[0].$fetch[$e]' src='pics/".$fetch[$e]."' alt='Image' width='18%' height='50px' style='position:relative;top:4px;margin-left:4px;pointer:cursor' onmouseover='change(this.id)'>";
	}
	$i=$i+4;
	echo "</div>";
	}
     
	
	else
		
	{   echo "<div class='col-sm-4 animate-box'  style='margin-bottom:50px'>";
		echo "<table class='table'>";
		for($e=$i;$e<=($i+5);$e++)
		{
          echo "<tr>
		  <th>";
		  echo mysql_field_name($query,$e);
		  echo "</th>";
		  echo "<th style='position:relative;left:40%'>";
		  ECHO $fetch[$e];
		  "</th>
		  </tr>";
		}
		$i=$i+5;
		  echo "</table>";
		  echo "</div>";
	}
	}
	
	
}
echo "</div>";
echo "</div>";
}

echo "</div>";
?>
</div>
	<footer id="fh5co-footer" role="contentinfo" style="position:relative;top:200px">
	
		<div class="container">
			<div class="col-md-3 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Developers</h3>
				<p>
				<a href="#" style="font-size:15px"><i>Grace</i></a><br>
			<a href="#" style="font-size:15px"><i>Rajesh</i></a><br>
			<a href="#" style="font-size:15px"><i>Manoj</i></a><br>
			<a href="#" style="font-size:15px"><i>Abiram</i></a><br>
			<a href="#" style="font-size:15px"><i>Shiva</i></a><br>
				</p>
				<p><a href="#" class="btn btn-primary btn-outline with-arrow btn-sm">Join Us <i class="icon-arrow-right"></i></a></p>
			</div>
			<div class="col-md-6 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Our Services</h3>
				<ul class="float">
					<li><a href="#">detailed-information</a></li>
					<li><a href="#">Branding &amp; Identity</a></li>
					<li><a href="#">comparision</a></li>
					<li><a href="#">used-cars</a></li>
				</ul>
				
			</div>

			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Follow Us</h3>
				<ul class="fh5co-social">
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-google-plus"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
				</ul>
			</div>
			
			
			<div class="col-sm-12 fh5co-copyright text-center">
				<p>&copy; All Rights Reserved.</p>	
			</div>
			
		</div>
	</footer>
	</div>
	<!--start of select modal-->
     
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
  
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" align="center">Select via below options</h4>
        </div>
        <div class="modal-body"  style="padding:40px 50px;">
     <div class="tab-content">
		<form action="ts.php" method="post">
				<select name="brand" style="width:100%;height:40px;border-radius:10px;margin-bottom:15px;">
			<option value="brand">Brand</option>
			<option value="x1">x1</option>
			<option value="f1">f3</option>
			<option value="bentley">bentley</option>
			</select><br>
			<select name="ct"  style="width:100%; height:40px;border-radius:10px;margin-bottom:15px;">
    				<option value="type">Car_type</option>
					<option value="suv">suv</option>
					<option value="sedan">sedan</option>
					<option value="coupe">coupe</option>
					<option value="muv">muv</option>
					
    			</select><br>
    			<select name="min"  style="width:100% ;height:40px;border-radius:10px;margin-bottom:15px;">
    				<option value="0">Min_price</option>
					<option value="100">100</option>
					<option value="200">200</option>
    			</select ><br>
				<select name="max"  style="width:100%;height:40px;border-radius:10px;margin-bottom:15px;">
    				<option value="0">Max_price</option>
					<option value="1000">1000</option>
					<option value="500000">500000</option>
    			</select><br>
    			
				
    			
		
  		</div>
  		
	
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-primary" value="search">
		  </form>
        </div>
      </div>
      
    </div>
  </div>
    <!--end of select-->
	<!--start of compare modal-->
  <div class="modal fade" id="compare" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" align="center">Select cars to compare</h4>
        </div>
        <div class="modal-body">
		<form id="fo" action="ctab.php" method="post" >
<label align="center"></label><br>
<select name="parts" align="center" style="width:80%; height:50px;border-radius:10px;margin-left:50px">
<option value="0">none</option>

<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
</select>


        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-danger btn-default pull-right" value="compare">
         </form>
        </div>
      </div>
      
    </div>
  </div>
	<!--end of compare modal-->
	<!--start of login modal-->
  <div class="modal fade" id="mylog" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Login</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <form role="form" action="login.php" method="post">
            <div class="form-group">
              <label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
              <input type="email" class="form-control" id="usrname" placeholder="Enter email" name="Email"required>
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
              <input type="password" class="form-control" id="psw" placeholder="Enter password" name="pass" required>
            </div>
           
              <button type="submit" class="btn btn-success btn-block"><span class="glyphicon glyphicon-off"></span> Login</button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
         
        </div>
      </div>
      
    </div>
  </div>
	<!--end of login modal-->
	
	<!--start of sign up modal-->
  <div class="modal fade" id="reg" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" align="center">Register</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          <form action="reg.php" method="post" onsubmit="return check()">
		  <input class="form-control" type="email" name="mail" placeholder="mail-id"><br>
		  <input class="form-control" type="password" id="pass" name="pass" placeholder="password"><br>
		  <input class="form-control" type="password" id="repass" name="repass" placeholder="renter password"><br>
		  
		
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-danger btn-default pull-right" value="register">
           </form>
        </div>
      </div>
      
    </div>
  </div>
	<!--end of sign up modal-->
	<!--start of post modal-->
  <div class="modal fade" id="post" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:5px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" align="center">Post</h4>
        </div>
        <div class="modal-body" style="padding:5px 50px;">
        <form action="in.php" method="post"  enctype="multipart/form-data">
<center>
<table class="table" cellpadding="10px">
<th>
<label>Mobile Number</label>
</th>
<td>
<input type="number" name="phone" maxlength="10">
</td>
</tr>

<tr><th><label>Car Front View</label>
</th>
<td>
<input type="file" name="im1">
</td>
</tr>
<tr><th><label>Car Back View</label>
</th>
<td>
<input type="file" name="im2">
</td>
</tr>
<tr><th><label>Car Top View</label>
</th>
<td>
<input type="file" name="im3">
</td>
</tr>
<tr><th><label>Car Side View</label>
</th>
<td>
<input type="file" name="im4">
</td>
</tr>
<tr><th><label>Car Side View</label>
</th>
<td>
<input type="file" name="im5">
</td>
</tr>
<tr><th><label>Brand</label>
</th>
<td>
<input type="text" name="brand">
</td>
</tr>
<tr><th><label>Model</label>
</th>
<td>
<input type="text" name="model">
</td>
</tr>
<tr><th><label>Year</label>
</th>
<td>
<input type="text" name="year">
</td>
</tr>
<td colspan="2">
<center>  
	</center>
</td>
</table>	  
		
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-danger btn-default pull-right sub" value="Post">
           </form>
        </div>
      </div>
      
    </div>
  </div>
	<!--end of post modal-->
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Owl Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>

	<!-- MAIN JS -->
	<script src="js/main.js"></script>
	<script>
	function check()
	{
	var x=document.getElementById('pass').value;
	var y=document.getElementById('repass').value;
	if(x==y)
	{
	alert("registration success9");
	return true;
	}
	else
	{
	alert("password doesnot match");
	return false;
	
	}
	}
	</script>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });

</script>
	</body>
</html>

