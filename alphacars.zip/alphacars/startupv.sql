-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 15, 2016 at 06:28 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `startupv`
--

-- --------------------------------------------------------

--
-- Table structure for table `cardata`
--

CREATE TABLE IF NOT EXISTS `cardata` (
  `s-no` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `image4` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `car_name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `fuel_type` varchar(255) NOT NULL,
  `top_speed` varchar(255) NOT NULL,
  `acceleration` varchar(255) NOT NULL,
  `engine_displacement` varchar(255) NOT NULL,
  `max_power` varchar(255) NOT NULL,
  `max_torque` varchar(255) NOT NULL,
  `engine_discription` varchar(255) NOT NULL,
  `turning_radius` varchar(255) NOT NULL,
  `noof_cylinders` varchar(255) NOT NULL,
  `drive_type` varchar(255) NOT NULL,
  `turbo_charges` varchar(255) NOT NULL,
  `super_charges` varchar(255) NOT NULL,
  `values_per_cylinder` varchar(255) NOT NULL,
  `compression_ratio` varchar(255) NOT NULL,
  `fuel_supply_system` varchar(255) NOT NULL,
  `gear_box` varchar(255) NOT NULL,
  `stgear_type` varchar(255) NOT NULL,
  `seating_capacity` varchar(255) NOT NULL,
  `noof_doors` varchar(255) NOT NULL,
  `car_length` varchar(255) NOT NULL,
  `car_width` varchar(255) NOT NULL,
  `car_height` varchar(255) NOT NULL,
  `ground_clearence` varchar(255) NOT NULL,
  `wheel_base` varchar(255) NOT NULL,
  `fuel_tank_capacity` varchar(255) NOT NULL,
  `cargo_volume` varchar(255) NOT NULL,
  `tyre_size` varchar(255) NOT NULL,
  `wheel_size` varchar(255) NOT NULL,
  `tyre_type` varchar(255) NOT NULL,
  `ac` varchar(255) NOT NULL,
  `power_steering` varchar(255) NOT NULL,
  `rear_ac_vents` varchar(255) NOT NULL,
  `en_st/sp_buttons` varchar(255) NOT NULL,
  `remote_tank_op` varchar(255) NOT NULL,
  `remote_fuel_lid_op` varchar(255) NOT NULL,
  `accessory_power_outlet` varchar(255) NOT NULL,
  `transition_type` varchar(255) NOT NULL,
  `foldable_rearseat` varchar(255) NOT NULL,
  `navigation_system` varchar(255) NOT NULL,
  `adjestable_seats` varchar(255) NOT NULL,
  `audio_player` varchar(255) NOT NULL,
  `low_fuel_warn_light` varchar(255) NOT NULL,
  `auto_climate_cont` varchar(255) NOT NULL,
  `rear_read_lamp` varchar(255) NOT NULL,
  `rear_seat_headrest` varchar(255) NOT NULL,
  `rear_cent_armrest` varchar(255) NOT NULL,
  `leather_seats` varchar(255) NOT NULL,
  `voice_control` varchar(255) NOT NULL,
  `shock_absorber_type` varchar(255) NOT NULL,
  `cruise_control` varchar(255) NOT NULL,
  `antilock` varchar(255) NOT NULL,
  `parking_sensor` varchar(255) NOT NULL,
  `central_locking` varchar(255) NOT NULL,
  `driver_airbag` varchar(255) NOT NULL,
  `passenger_airbag` varchar(255) NOT NULL,
  `front_airbags` varchar(255) NOT NULL,
  `rear_airbags` varchar(255) NOT NULL,
  `rear_seatbelts` varchar(255) NOT NULL,
  `smart_acces` varchar(255) NOT NULL,
  `seat_belt_warn` varchar(255) NOT NULL,
  `brake_assist` varchar(255) NOT NULL,
  `crash_sensor` varchar(255) NOT NULL,
  `anti_theft_alarm` varchar(255) NOT NULL,
  `power_door_locks` varchar(255) NOT NULL,
  `child_saftey_locks` varchar(255) NOT NULL,
  `side_impact_beams` varchar(255) NOT NULL,
  `front_impact_beams` varchar(255) NOT NULL,
  `rear_view_mirrors` varchar(255) NOT NULL,
  `engine_immoblizer` varchar(255) NOT NULL,
  `automatic_headlamps` varchar(255) NOT NULL,
  `front_brake_type` varchar(255) NOT NULL,
  `rear_brake_type` varchar(255) NOT NULL,
  `hight_adj_fr_seat_belts` varchar(255) NOT NULL,
  PRIMARY KEY (`s-no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `cardata`
--

INSERT INTO `cardata` (`s-no`, `image`, `image1`, `image2`, `image3`, `image4`, `brand`, `model`, `car_name`, `price`, `fuel_type`, `top_speed`, `acceleration`, `engine_displacement`, `max_power`, `max_torque`, `engine_discription`, `turning_radius`, `noof_cylinders`, `drive_type`, `turbo_charges`, `super_charges`, `values_per_cylinder`, `compression_ratio`, `fuel_supply_system`, `gear_box`, `stgear_type`, `seating_capacity`, `noof_doors`, `car_length`, `car_width`, `car_height`, `ground_clearence`, `wheel_base`, `fuel_tank_capacity`, `cargo_volume`, `tyre_size`, `wheel_size`, `tyre_type`, `ac`, `power_steering`, `rear_ac_vents`, `en_st/sp_buttons`, `remote_tank_op`, `remote_fuel_lid_op`, `accessory_power_outlet`, `transition_type`, `foldable_rearseat`, `navigation_system`, `adjestable_seats`, `audio_player`, `low_fuel_warn_light`, `auto_climate_cont`, `rear_read_lamp`, `rear_seat_headrest`, `rear_cent_armrest`, `leather_seats`, `voice_control`, `shock_absorber_type`, `cruise_control`, `antilock`, `parking_sensor`, `central_locking`, `driver_airbag`, `passenger_airbag`, `front_airbags`, `rear_airbags`, `rear_seatbelts`, `smart_acces`, `seat_belt_warn`, `brake_assist`, `crash_sensor`, `anti_theft_alarm`, `power_door_locks`, `child_saftey_locks`, `side_impact_beams`, `front_impact_beams`, `rear_view_mirrors`, `engine_immoblizer`, `automatic_headlamps`, `front_brake_type`, `rear_brake_type`, `hight_adj_fr_seat_belts`) VALUES
(3, 'bmw_435i_zhp_coupe_2016-852x480.jpg', '', '', '', '', 'f1', 'sedan', 'M3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9', 'f10', 'f11', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18', 'f19', 'f20', 'f21', 'f22', 'f23', 'f24', 'f25', 'f26', 'f27', 'f28', 'f29', 'f30', 'f31', 'f32', 'f33', 'f34', 'f35', 'f36', 'f37', 'f38', 'f39', 'f40', 'f41', 'f42', 'f43', 'f44', 'f45', 'f46', 'f47', 'f48', 'f49', 'f50', 'f51', 'f52', 'f53', 'f54', 'f55', 'f56', 'f57', 'f58', 'f59', 'f60', 'f61', 'f62', 'f63', 'f64', 'f65', 'f66', 'f67', 'f68', 'f69', 'f70', 'f71', 'f72', 'f74', 'f77', 'f78', 'f79', 'f80'),
(4, 'cadillac_elr_2016-852x480.jpg', '', '', '', '', 'x1', 'coupe', 'h1', '5', 'fhg', 'hfgh', 'fhg', 'fhg', 'fhg', 'fgh', 'fgh', 'fgh', '2', 'rwd', 'no', 'no', '2', 'gf', 'gjhgj', '4', 'hjg', '2', '2', 'hghjgj', 'jhghj', 'ghg', 'hjg', 'hjg', 'hg', 'hj', 'hjjhghj', 'gh', 'jghj', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'auto', 'gf', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'jij', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'no', 'rytryt', 'rt', 'rtr', 'r'),
(5, 'cadillac_elr_2016-852x480.jpg', '', '', '', '', 'x2', 'coupe', 'h2', '5', 'fhg', 'hfgh', 'fhg', 'fhg', 'fhg', 'fgh', 'fgh', 'fgh', '2', 'rwd', 'no', 'no', '2', 'gf', 'gjhgj', '4', 'hjg', '2', '2', 'hghjgj', 'jhghj', 'ghg', 'hjg', 'hjg', 'hg', 'hj', 'hjjhghj', 'gh', 'jghj', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'auto', 'gf', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'jij', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'no', 'rytryt', 'rt', 'rtr', 'r'),
(6, '', '', '', '', '', 'x3', 'muv', 'h3', '5', 'fhg', 'hfgh', 'fhg', 'fhg', 'fhg', 'fgh', 'fgh', 'fgh', '2', 'rwd', 'no', 'no', '2', 'gf', 'gjhgj', '4', 'hjg', '2', '2', 'hghjgj', 'jhghj', 'ghg', 'hjg', 'hjg', 'hg', 'hj', 'hjjhghj', 'gh', 'jghj', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'auto', 'gf', 'no', 'no', 'yes', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'jij', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'no', 'rytryt', 'rt', 'rtr', 'r'),
(7, '', '', '', '', '', 'MEARK', 'suv', 'JHDAK', '20000', 'SAF', 'HGGF', 'GFGH', 'FGH', 'FHGF', 'GHF', 'F', 'HGFHG', '454', 'fwd', 'no', 'no', '5564', 'GJHGHJ', 'JGHK', '5', 'GJH', '1', '5686', '3653', '543', 'HTF', 'GJYG', 'YJY', 'TY', 'TYU', 'TYU', 'UY', 'YUT', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'auto', 'GYU', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'UYT', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'U567T', 'HFYT', 'yes'),
(8, '', '', '', '', '', 'SJGSJK', '', 'GJ', '', 'GHJ', 'GHJ', 'GHJ', 'GHJ', 'GHJ', 'GHJ', 'GHJ', 'GJH', '2', 'fwd', 'yes', 'yes', '3563', 'FDFDH', 'HF', '4', 'HGF', '65', '57', 'DGFD', 'GHF', 'FF', 'HGFHG', 'FGH', 'FHG', 'FGH', 'FHG', 'FHGF', 'HGF', 'no', 'no', 'yes', 'yes', 'no', 'yes', 'yes', 'auto', 'FDG', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'yes', 'no', 'no', 'HFG', 'no', 'no', 'no', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'SFG', 'SGF', 'no'),
(9, 'jaguar_f_pace.jpg', '', '', '', '', '', 'sedan', '', '', '', '', '', '', '', '', '', '', '', 'SELECT DRIVE TYPE', '', '', '', '', '', 'no of gears', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'manual', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, 'audi_a5_coupe_2016-852x480.jpg', '', '', '', '', 'audi', 'sedan', 'coupe', '', '', '', '', '', '', '', '', '', '', 'SELECT DRIVE TYPE', '', '', '', '', '', 'no of gears', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'manual', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'bentley_continent.jpg', '', '', '', '', 'bentley', 'sedan', 'continent', '500000', 'petrol', '300', '80', '300', '300', '300', 'v8', '12', '4', '4wd', 'yes', 'yes', '3', '234', 'petrol', '7', 'yes', '2', '2', '12222', '23455', '33333', '12', '1', '32lts', '344', '23', '23', 'rubber', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'auto', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'carbon_fibre', 'carbon_fibre', 'yes'),
(12, 'av5.jpg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'SELECT DRIVE TYPE', '', '', '', '', '', 'no of gears', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'manual', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, 'a1.jpg', 'abarth.jpg', 'a14.jpg', 'a13.jpg', 'a11.jpg', 'abarth', 'hatchback', 'a1', '25000', '', '', '', '', '', '', '', '', '', 'SELECT DRIVE TYPE', '', '', '', '', '', 'no of gears', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'manual', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, '2012_buick_regal_gs.jpg', 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', 'bentley_continental_gt_speed_black_edition_2017.jpg', 'bmw_435i_zhp_coupe_2016-852x480.jpg', 'cadillac_xt5_2017-852x480.jpg', 'Mercedes-Benz', 'sedan', 'A-Class A200 D sport addition', 'Rs.26,95,000', 'Diesel', '210 Kmph', '8.8 Seconds', '2143', '136bhp@3600-4400rpm', '300Nm@1400-3000rpm', '2.2-litre 136bhp 16V In-Line Diesel Engine', '5.5 meters', '4', 'FWD', 'YES', 'NO', '4', '-', 'CRDi', '7 speed', 'Rack & Pinion', '5', '5', '4299mm', '2022mm', '1433mm', '160mm', '2699mm', '50', '341-litres', '205/55 R16', '-', 'Tubeless, Radial', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'Automatic', '60:40 Split', 'NO', 'YES', 'YES', 'YRES', 'NO', 'NO', 'YES', 'YES', 'YES', 'NO', '-', 'YES', 'YES', 'Rear', 'YES', 'YES', 'YES', 'YES', 'NO', 'YES', 'NO', 'YES', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'Ventilated Disc', 'Disc', 'NO'),
(15, 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', 'bentley_continental_gt_v8_s_2014-852x480.jpg', 'bmw_m760li_xdrive_v12_excellence_2017-852x480.jpg', 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', 'AUDI', 'coupe', 'A4', 'Rs.26,95,000', 'Diesel', '210 Kmph', '8.8 Seconds', '2143', '136bhp@3600-4400rpm', '300Nm@1400-3000rpm', '2.2-litre 136bhp 16V In-Line Diesel Engine', '5.5 meters', '4', 'FWD', 'YES', 'NO', '4', '-', 'CRDi', '7 speed', 'Rack & Pinion', '5', '5', '4299mm', '2022mm', '1433mm', '160mm', '2699mm', '50', '341-litres', '205/55 R16', '-', 'Tubeless, Radial', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'Automatic', '60:40 Split', 'NO', 'YES', 'YES', 'YRES', 'NO', 'NO', 'YES', 'YES', 'YES', 'NO', '-', 'YES', 'YES', 'Rear', 'YES', 'YES', 'YES', 'YES', 'NO', 'YES', 'NO', 'YES', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'Ventilated Disc', 'Disc', 'NO'),
(16, 'cadillac_xt5_2017-852x480.jpg', 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', 'audi_r8_coupe_v10_plus_selection_24h_2016-852x480.jpg', '', '', 'AUDI', 'suv', 'a3', 'Rs.26,95,000', 'Diesel', '210 Kmph', '8.8 Seconds', '2143', '136bhp@3600-4400rpm', '300Nm@1400-3000rpm', '2.2-litre 136bhp 16V In-Line Diesel Engine', '5.5 meters', '4', 'FWD', 'YES', 'NO', '4', '-', 'CRDi', '7 speed', 'Rack & Pinion', '5', '5', '4299mm', '2022mm', '1433mm', '160mm', '2699mm', '50', '341-litres', '205/55 R16', '-', 'Tubeless, Radial', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'Automatic', '60:40 Split', 'NO', 'YES', 'YES', 'YRES', 'NO', 'NO', 'YES', 'YES', 'YES', 'NO', '-', 'YES', 'YES', 'Rear', 'YES', 'YES', 'YES', 'YES', 'NO', 'YES', 'NO', 'YES', 'YES', 'YES', 'NO', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'Ventilated Disc', 'Disc', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `s.no` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`s.no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`s.no`, `email`, `password`) VALUES
(1, 'shiva@gmail.com', 'kill'),
(2, 'rudrravarjula1234@gmail.com', 'rajesh2767');

-- --------------------------------------------------------

--
-- Table structure for table `usedcars`
--

CREATE TABLE IF NOT EXISTS `usedcars` (
  `sno` bigint(255) NOT NULL AUTO_INCREMENT,
  `im1` varchar(255) NOT NULL,
  `im2` varchar(255) NOT NULL,
  `im3` varchar(255) NOT NULL,
  `im4` varchar(255) NOT NULL,
  `im5` varchar(255) NOT NULL,
  `ph.no` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` int(255) NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `usedcars`
--

INSERT INTO `usedcars` (`sno`, `im1`, `im2`, `im3`, `im4`, `im5`, `ph.no`, `email`, `brand`, `model`, `year`) VALUES
(1, 'ber1.jpg', 'ber2.jpg', 'ber3.jpg', 'ber4.jpg', 'ber5.jpg', 32456789, 'shiva@gmail.com', 'FERRARI', 'berlinetta', 2015),
(2, 'cr3.jpg', 'cr1.jpg', 'cr2.jpg', 'cr6.jpg', 'cr5.jpg', 2147483647, 'shiva@gmail.com', 'chevorlet', 'corvette z28', 2014),
(3, 'c1.jpg', 'c5.jpg', 'c3.jpg', 'r84.jpg', 'm61.jpg', 2147483647, 'rudrravarjula1234@gmail.com', 'BMW', 'A1', 2019),
(4, 'c1.jpg', 'c5.jpg', 'c3.jpg', 'r84.jpg', 'm61.jpg', 2147483647, 'rudrravarjula1234@gmail.com', 'BMW', 'A1', 2019);
