<?php
error_reporting(0);
mysql_connect("localhost","root","") or die("conn error");
mysql_select_db("startupv") or die("db error");
$a=$_POST['mail'];
$b=$_POST['pass'];
mysql_query("INSERT INTO registration (email,password) VALUES ('$a', '$b') ") or die("qu error");
echo "<script>window.location='index.php'</script>";
?>