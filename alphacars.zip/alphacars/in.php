<?php
session_start();
if($_SESSION['loged'])
{
	$t=$_SESSION['name'];
echo "<script>alert('$t')</script>";
}
else
{
 	
}

error_reporting(0);
mysql_connect("localhost","root","") or die("conn error");
mysql_select_db("startupv") or die("db error");


$f1=$_POST['phone'];
$f2=$t;
$f3=$_FILES['im1']['name'];
$img_dir='pics/';
move_uploaded_file($_FILES['im1']['tmp_name'],$img_dir.$_FILES['im1']['name']);
$f4=$_FILES['im2']['name'];
$img_dir='pics/';
move_uploaded_file($_FILES['im2']['tmp_name'],$img_dir.$_FILES['im2']['name']);
$f5=$_FILES['im3']['name'];
$img_dir='pics/';
move_uploaded_file($_FILES['im3']['tmp_name'],$img_dir.$_FILES['im3']['name']);
$f6=$_FILES['im4']['name'];
$img_dir='pics/';
move_uploaded_file($_FILES['im4']['tmp_name'],$img_dir.$_FILES['im4']['name']);
$f7=$_FILES['im5']['name'];
$img_dir='pics/';
move_uploaded_file($_FILES['im5']['tmp_name'],$img_dir.$_FILES['im5']['name']);
$f8=$_POST['brand'];
$f9=$_POST['model'];
$f10=$_POST['year'];
$query="INSERT INTO `startupv`.`usedcars` ( `ph.no`, `email`, `im1`, `im2`, `im3`, `im4`, `im5`, `brand`, `model`, `year`) VALUES ('$f1', '$f2', '$f3', '$f4', '$f5', '$f6', '$f7', '$f8', '$f9', '$f10')";
$in=mysql_query($query) or die("qu error");
if($in)
{
	echo "<script>alert('posted successfully')</script>";
	echo "<script>window.location='index.php'</script>";
	
}

?>