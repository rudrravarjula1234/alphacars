<?php
session_start();
error_reporting(0);
mysql_connect('localhost','root','') or die(mysql_error());
mysql_select_db('startupv') or die(mysql_error());
if(isset($_POST['Email'])&&isset($_POST['pass']))
{
$a=$_POST['Email'];
$b=$_POST['pass'];
$c="SELECT * FROM  registration WHERE email='$a' AND password='$b'"; 
$d=mysql_query($c) or die("Error");
$e=mysql_num_rows($d);
if($e==1)
{
	
	    $_SESSION=array();
		$_SESSION['loged']="yes";
		$_SESSION['name']=$a;
		$url="location:index.php";
		
		header($url);
}
else
{   
 echo "<script>alert('your entry details are wrong');</script>";
	echo "<script>window.location='index.php'</script>";
}
}
else
{
echo "<script>alert('fill the fields')</script>";	
echo "<script>window.location='index.php'</script>";
}

?>
